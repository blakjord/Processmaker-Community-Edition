<?php
/**
 * class.pmRestRequest.php
 *  
 */

  class pmRestRequestClass extends PMPlugin {
    function __construct() {
      set_include_path(
        PATH_PLUGINS . 'pmRestRequest' . PATH_SEPARATOR .
        get_include_path()
      );
    }

    function setup()
    {
    }

    function getFieldsForPageSetup()
    {
    }

    function updateFieldsForPageSetup()
    {
    }

  }
